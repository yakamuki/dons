<?php
// Speech is silver but silence is gold.
