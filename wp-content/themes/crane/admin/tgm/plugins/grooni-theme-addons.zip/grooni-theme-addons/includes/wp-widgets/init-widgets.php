<?php defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );
/**
 * Init all additional widgets.
 *
 * @package crane
 */


include_once 'class-Grooni_Widget_Banner.php';
include_once 'class-Grooni_Widget_RecentImages.php';
include_once 'class-Grooni_Widget_RecentPosts.php';
include_once 'class-Grooni_Widget_RecentComments.php';
include_once 'class-Grooni_Widget_PortfolioCategory.php';
