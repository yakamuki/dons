(function( $ ) {
	'use strict';

})( jQuery );

