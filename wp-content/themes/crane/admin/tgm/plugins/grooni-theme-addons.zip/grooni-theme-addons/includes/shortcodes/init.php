<?php defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );


require_once dirname( __FILE__ ) . '/shortcode-soundcloud.php';
